/// @ref core
/// @file glm/common.hpp

#include "detail/setup.hpp"

#pragma once

#include "detail/func_common.hpp"
