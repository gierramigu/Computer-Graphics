/// @ref core
/// @file glm/exponential.hpp

#include "detail/setup.hpp"

#pragma once

#include "detail/func_exponential.hpp"
